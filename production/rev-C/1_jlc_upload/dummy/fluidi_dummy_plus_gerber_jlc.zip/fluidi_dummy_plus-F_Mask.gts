G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.8-10.0.8~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-11-09T07:40:50+01:00*
G04 #@! TF.ProjectId,fluidi_dummy_plus,666c7569-6469-45f6-9475-6d6d795f706c,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8-10.0.8~ubuntu24.04.1) date 2026-11-09 07:40:50*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,4.500000X5.000000*%
%ADD11C,1.000000*%
%ADD12C,19.000000*%
G04 APERTURE END LIST*
D10*
X114850000Y-100000000D03*
D11*
X111600000Y-97100000D03*
D12*
X100000000Y-100000000D03*
D11*
X111600000Y-102900000D03*
M02*
